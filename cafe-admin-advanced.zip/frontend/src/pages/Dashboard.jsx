import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'
import logo from '../assets/logo2.jpg'
import Employees from '../sections/Employees.jsx'
import Attendance from '../sections/Attendance.jsx'
import Withdrawals from '../sections/Withdrawals.jsx'
import Products from '../sections/Products.jsx'
import Sales from '../sections/Sales.jsx'
import Debts from '../sections/Debts.jsx'
import Expenses from '../sections/Expenses.jsx'
import Reports from '../sections/Reports.jsx'
import Settings from '../sections/Settings.jsx'

export default function Dashboard({ onLogout }){
  const [view,setView]=useState('home')
  const [kpis,setKpis]=useState({salesToday:0, salesMonth:0, employees:0})

  const loadKpis = async ()=>{
    const today = new Date().toISOString().slice(0,10)
    const first = new Date(); first.setDate(1)
    const monthStart = first.toISOString().slice(0,10)

    const { data: empcount } = await supabase.from('employees').select('id', { count: 'exact', head: true })
    const { data: todayRows } = await supabase.from('orders').select('total,created_at').gte('created_at', today)
    const { data: monthRows } = await supabase.from('orders').select('total,created_at').gte('created_at', monthStart)
    const total = (rows)=> (rows||[]).reduce((s,r)=> s + Number(r.total||0), 0)
    setKpis({ salesToday: total(todayRows), salesMonth: total(monthRows), employees: empcount?.length ?? 0 })
  }
  useEffect(()=>{ loadKpis() },[view])

  const time = new Date().toLocaleString('ar-EG', {weekday:'short', year:'numeric', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'})

  return (
    <div className="app">
      <div className="topbar">
        <div className="brand">
          <img src={logo} alt="" />
          <div>
            <div style={{fontWeight:700}}>{import.meta.env.VITE_BRAND_NAME || 'المقهى'}</div>
            <div className="small-muted">{time}</div>
          </div>
        </div>
        <div className="nav">
          <button className="btn ghost" onClick={()=>setView('home')}>الرئيسية</button>
          <button className="btn ghost" onClick={()=>setView('employees')}>الموظفين</button>
          <button className="btn ghost" onClick={()=>setView('attendance')}>الحضور</button>
          <button className="btn ghost" onClick={()=>setView('withdrawals')}>السحوبات</button>
          <button className="btn ghost" onClick={()=>setView('products')}>المنتجات</button>
          <button className="btn ghost" onClick={()=>setView('sales')}>المبيعات</button>
          <button className="btn ghost" onClick={()=>setView('debts')}>الديون</button>
          <button className="btn ghost" onClick={()=>setView('expenses')}>المصروفات</button>
          <button className="btn ghost" onClick={()=>setView('reports')}>التقارير</button>
          <button className="btn danger" onClick={onLogout}>خروج</button>
        </div>
      </div>

      <div className="container">
        {view==='home' && (
          <>
            <div className="kpis">
              <div className="card"><div className="small-muted">مبيعات اليوم</div><h2>{kpis.salesToday.toFixed(2)}</h2></div>
              <div className="card"><div className="small-muted">مبيعات الشهر</div><h2>{kpis.salesMonth.toFixed(2)}</h2></div>
              <div className="card"><div className="small-muted">عدد الموظفين</div><h2>{kpis.employees}</h2></div>
              <div className="card"><div className="small-muted">الوقت</div><h2>{time}</h2></div>
            </div>
            <div className="grid-icons">
              <div className="tile" onClick={()=>setView('employees')}>👥 <b>الموظفين</b></div>
              <div className="tile" onClick={()=>setView('attendance')}>📅 <b>الحضور</b></div>
              <div className="tile" onClick={()=>setView('withdrawals')}>💸 <b>السحوبات</b></div>
              <div className="tile" onClick={()=>setView('products')}>🧾 <b>المنتجات</b></div>
              <div className="tile" onClick={()=>setView('sales')}>🛒 <b>المبيعات</b></div>
              <div className="tile" onClick={()=>setView('debts')}>📄 <b>الديون</b></div>
              <div className="tile" onClick={()=>setView('expenses')}>💼 <b>المصروفات</b></div>
              <div className="tile" onClick={()=>setView('reports')}>📊 <b>التقارير</b></div>
            </div>
          </>
        )}
        {view==='employees'&&<Employees/>}
        {view==='attendance'&&<Attendance/>}
        {view==='withdrawals'&&<Withdrawals/>}
        {view==='products'&&<Products/>}
        {view==='sales'&&<Sales/>}
        {view==='debts'&&<Debts/>}
        {view==='expenses'&&<Expenses/>}
        {view==='reports'&&<Reports/>}
        {view==='settings'&&<Settings/>}
      </div>
    </div>
  )
}
