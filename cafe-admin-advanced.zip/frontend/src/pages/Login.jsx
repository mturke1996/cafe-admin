import React, { useState } from 'react'
import { supabase } from '../services/supabaseClient'
import logo from '../assets/logo1.jpg'

export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [loading,setLoading]=useState(false)
  const signIn = async (e)=>{
    e.preventDefault()
    setLoading(true)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)
    if(error) return alert(error.message)
  }
  const demo = async ()=>{
    // create or sign in a demo user
    const e='owner@demo.local', p='Demo1234!'
    await supabase.auth.signUp({ email:e, password:p }).catch(()=>{})
    await supabase.auth.signInWithPassword({ email:e, password:p })
  }
  return (
    <div className="auth-wrap">
      <div className="auth-hero">
        <img src={logo} alt="" className="hero-logo" />
        <div className="brand-title">{import.meta.env.VITE_BRAND_NAME || 'مقهى'}</div>
        <div className="brand-sub">لوحة إدارة احترافية وسريعة</div>
      </div>
      <div className="auth-card">
        <h2>تسجيل الدخول</h2>
        <form onSubmit={signIn} className="col" style={{display:'flex',flexDirection:'column',gap:10}}>
          <input className="input" placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)} />
          <div className="row" style={{justifyContent:'space-between'}}>
            <button className="btn primary" disabled={loading}>{loading?'جارٍ...':'دخول'}</button>
            <button className="btn ghost" type="button" onClick={demo}>دخول تجريبي</button>
          </div>
          <div className="small-muted">أضف مستخدمًا من Supabase → Auth للتجربة بحسابك.</div>
        </form>
      </div>
    </div>
  )
}
