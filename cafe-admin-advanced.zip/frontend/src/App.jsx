import React, { useEffect, useState } from 'react'
import { supabase } from './services/supabaseClient'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'

export default function App(){
  const [session, setSession] = useState(null)

  useEffect(()=>{
    supabase.auth.getSession().then(({ data })=> setSession(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, sess)=> setSession(sess))
    return ()=> sub.subscription.unsubscribe()
  },[])

  if(!session) return <Login />
  return <Dashboard onLogout={()=> supabase.auth.signOut()} />
}
