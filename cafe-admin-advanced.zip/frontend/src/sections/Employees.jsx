import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Employees(){
  const [list,setList]=useState([])
  const [name,setName]=useState(''); const [phone,setPhone]=useState(''); const [daily,setDaily]=useState(''); const [photo,setPhoto]=useState(null)

  const load = async ()=>{
    const { data } = await supabase.from('employees').select('*').order('created_at',{ascending:false})
    setList(data||[])
  }
  useEffect(()=>{ load() },[])

  const upload = async (file)=>{
    if(!file) return null
    const path = `photos/${Date.now()}_${file.name}`
    const { data, error } = await supabase.storage.from('employee-photos').upload(path, file)
    if(error){ alert(error.message); return null }
    return supabase.storage.from('employee-photos').getPublicUrl(path).data.publicUrl
  }

  const add = async ()=>{
    if(!name || !daily) return alert('أدخل الاسم واليومية')
    const photo_url = await upload(photo)
    const { error } = await supabase.from('employees').insert([{ name, phone, daily_rate: Number(daily), photo_url }])
    if(error) return alert(error.message)
    setName(''); setPhone(''); setDaily(''); setPhoto(null); load()
  }

  return (
    <div className="card">
      <h3>إدارة الموظفين</h3>
      <div className="form-row">
        <input className="input" placeholder="الاسم" value={name} onChange={e=>setName(e.target.value)} />
        <input className="input" placeholder="الهاتف" value={phone} onChange={e=>setPhone(e.target.value)} />
        <input className="input" placeholder="اليومية" value={daily} onChange={e=>setDaily(e.target.value)} />
        <input className="input" type="file" onChange={e=>setPhoto(e.target.files[0])} />
        <button className="btn primary" onClick={add}>إضافة</button>
      </div>

      <table className="table" style={{marginTop:10}}>
        <thead><tr><th>الصورة</th><th>الاسم</th><th>الهاتف</th><th>اليومية</th><th>أنشئ</th></tr></thead>
        <tbody>
          {list.map(r=>(
            <tr key={r.id}>
              <td><img src={r.photo_url} style={{width:40,height:40,borderRadius:8,objectFit:'cover'}}/></td>
              <td>{r.name}</td><td>{r.phone}</td><td>{r.daily_rate}</td><td>{new Date(r.created_at).toLocaleDateString('ar-EG')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
