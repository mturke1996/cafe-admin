import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Attendance(){
  const [emps,setEmps]=useState([])
  const [date,setDate]=useState(new Date().toISOString().slice(0,10))

  useEffect(()=>{ (async()=>{ const { data } = await supabase.from('employees').select('id,name'); setEmps(data||[]) })() },[])

  const mark = async (employee_id, status)=>{
    const { error } = await supabase.from('attendance').insert([{ employee_id, date, status }])
    if(error) return alert(error.message)
    alert('تم تسجيل '+(status==='present'?'حضور':'غياب'))
  }

  return (
    <div className="card">
      <h3>الحضور والغياب</h3>
      <div className="form-row">
        <label>التاريخ <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} /></label>
      </div>
      <div className="grid-icons" style={{marginTop:12}}>
        {emps.map(e=>(
          <div className="tile" key={e.id}>
            <b>{e.name}</b>
            <div className="row" style={{justifyContent:'center'}}>
              <button className="btn success" onClick={()=>mark(e.id,'present')}>حضور</button>
              <button className="btn ghost" onClick={()=>mark(e.id,'absent')}>غياب</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
