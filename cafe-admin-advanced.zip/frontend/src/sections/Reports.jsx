import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Reports(){
  const [emps,setEmps]=useState([]); const [selected,setSelected]=useState(null)
  useEffect(()=>{ (async()=>{ const { data } = await supabase.from('employees').select('*'); setEmps(data||[]) })() },[])

  const open = async (emp)=>{
    const { data:att } = await supabase.from('attendance').select('*').eq('employee_id', emp.id).order('date',{ascending:true})
    const { data:wd }  = await supabase.from('withdrawals').select('*').eq('employee_id', emp.id).order('date',{ascending:true})
    setSelected({ emp, att:att||[], wd:wd||[] })
    setTimeout(()=> window.print(), 300)
  }

  return (
    <div className="card">
      <h3>التقارير</h3>
      {!selected && (
        <div className="grid-icons">
          {emps.map(e=>(
            <div key={e.id} className="tile">
              <b>{e.name}</b>
              <button className="btn ghost" onClick={()=>open(e)}>طباعة تقرير</button>
            </div>
          ))}
        </div>
      )}
      {selected && (
        <div className="print-paper">
          <h3>تقرير موظف</h3>
          <div className="profile-header">
            <img src={selected.emp.photo_url} className="profile-photo" />
            <div>
              <div><b>الاسم:</b> {selected.emp.name}</div>
              <div><b>الهاتف:</b> {selected.emp.phone}</div>
              <div><b>اليومية:</b> {selected.emp.daily_rate}</div>
            </div>
          </div>
          <h4>الحضور</h4>
          <table className="table">
            <thead><tr><th>التاريخ</th><th>الحالة</th></tr></thead>
            <tbody>{selected.att.map((a,i)=>(<tr key={i}><td>{a.date}</td><td>{a.status==='present'?'حضور':'غياب'}</td></tr>))}</tbody>
          </table>
          <h4>السحوبات</h4>
          <table className="table">
            <thead><tr><th>التاريخ</th><th>المبلغ</th></tr></thead>
            <tbody>{selected.wd.map((a,i)=>(<tr key={i}><td>{a.date}</td><td>{Number(a.amount).toFixed(2)}</td></tr>))}</tbody>
          </table>
        </div>
      )}
    </div>
  )
}
