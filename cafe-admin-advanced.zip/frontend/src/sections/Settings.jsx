import React, { useState } from 'react'

export default function Settings(){
  const [brand,setBrand]=useState(import.meta.env.VITE_BRAND_NAME||'المقهى')
  const save = ()=> alert('يمكنك تغيير الاسم من ملف .env: VITE_BRAND_NAME')
  return (
    <div className="card">
      <h3>الإعدادات</h3>
      <div className="form-row">
        <input className="input" value={brand} onChange={e=>setBrand(e.target.value)} />
        <button className="btn primary" onClick={save}>حفظ</button>
      </div>
      <div className="small-muted">لتغيير اسم العلامة فعليًا، حرر قيمة VITE_BRAND_NAME في ملف .env ثم أعد تشغيل الخادم.</div>
    </div>
  )
}
