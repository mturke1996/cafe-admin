import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Withdrawals(){
  const [emps,setEmps]=useState([]); const [emp,setEmp]=useState(''); const [amount,setAmount]=useState(''); const [date,setDate]=useState(new Date().toISOString().slice(0,10))
  useEffect(()=>{ (async()=>{ const { data } = await supabase.from('employees').select('id,name'); setEmps(data||[]) })() },[])
  const add = async ()=>{
    if(!emp || !amount) return alert('اختر موظف والمبلغ')
    const { error } = await supabase.from('withdrawals').insert([{ employee_id: emp, amount: Number(amount), date }])
    if(error) return alert(error.message)
    alert('تمت إضافة سحب'); setEmp(''); setAmount('')
  }
  return (
    <div className="card">
      <h3>السحوبات</h3>
      <div className="form-row">
        <select className="input" value={emp} onChange={e=>setEmp(e.target.value)}>
          <option value="">اختر موظف</option>
          {emps.map(x=> <option key={x.id} value={x.id}>{x.name}</option>)}
        </select>
        <input className="input" placeholder="المبلغ" value={amount} onChange={e=>setAmount(e.target.value)} />
        <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} />
        <button className="btn primary" onClick={add}>تسجيل سحب</button>
      </div>
    </div>
  )
}
