import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Expenses(){
  const [title,setTitle]=useState(''); const [amount,setAmount]=useState(''); const [rows,setRows]=useState([])
  const load=async()=>{ const { data } = await supabase.from('expenses').select('*').order('created_at',{ascending:false}); setRows(data||[]) }
  useEffect(()=>{ load() },[])
  const add=async()=>{
    if(!title||!amount) return alert('أدخل البند والمبلغ')
    const { error } = await supabase.from('expenses').insert([{ title, amount:Number(amount) }])
    if(error) return alert(error.message)
    setTitle(''); setAmount(''); load()
  }
  return (
    <div className="card">
      <h3>المصروفات</h3>
      <div className="form-row">
        <input className="input" placeholder="اسم البند" value={title} onChange={e=>setTitle(e.target.value)} />
        <input className="input" placeholder="المبلغ" value={amount} onChange={e=>setAmount(e.target.value)} />
        <button className="btn primary" onClick={add}>إضافة</button>
      </div>
      <table className="table" style={{marginTop:10}}>
        <thead><tr><th>البند</th><th>المبلغ</th><th>تاريخ</th></tr></thead>
        <tbody>{rows.map(r=>(<tr key={r.id}><td>{r.title}</td><td>{Number(r.amount).toFixed(2)}</td><td>{new Date(r.created_at).toLocaleDateString('ar-EG')}</td></tr>))}</tbody>
      </table>
    </div>
  )
}
