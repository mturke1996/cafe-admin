import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Products(){
  const [name,setName]=useState(''); const [price,setPrice]=useState('')
  const [rows,setRows]=useState([])
  const load=async()=>{ const { data } = await supabase.from('products').select('*').order('created_at',{ascending:false}); setRows(data||[]) }
  useEffect(()=>{ load() },[])
  const add=async()=>{
    if(!name||!price) return alert('أدخل الاسم والسعر')
    const { error } = await supabase.from('products').insert([{ name, price: Number(price) }])
    if(error) return alert(error.message)
    setName(''); setPrice(''); load()
  }
  return (
    <div className="card">
      <h3>المنتجات</h3>
      <div className="form-row">
        <input className="input" placeholder="اسم المنتج" value={name} onChange={e=>setName(e.target.value)} />
        <input className="input" placeholder="السعر" value={price} onChange={e=>setPrice(e.target.value)} />
        <button className="btn primary" onClick={add}>إضافة</button>
      </div>
      <table className="table" style={{marginTop:10}}>
        <thead><tr><th>الاسم</th><th>السعر</th><th>تاريخ</th></tr></thead>
        <tbody>
          {rows.map(r=>(<tr key={r.id}><td>{r.name}</td><td>{Number(r.price).toFixed(2)}</td><td>{new Date(r.created_at).toLocaleDateString('ar-EG')}</td></tr>))}
        </tbody>
      </table>
    </div>
  )
}
