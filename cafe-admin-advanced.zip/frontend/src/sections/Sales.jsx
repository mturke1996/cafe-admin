import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Sales(){
  const [products,setProducts]=useState([]); const [items,setItems]=useState([]); const [customer,setCustomer]=useState('')
  useEffect(()=>{ (async()=>{ const { data } = await supabase.from('products').select('*'); setProducts(data||[]) })() },[])
  const addItem=(p)=> setItems(prev=>{
    const i=prev.findIndex(x=>x.id===p.id); if(i>-1){ const a=[...prev]; a[i].qty++; return a } return [...prev,{...p,qty:1}]
  })
  const setQty=(id,qty)=> setItems(prev=> prev.map(x=> x.id===id?{...x,qty:Number(qty)}:x))
  const total = items.reduce((s,x)=> s + x.qty*Number(x.price||0), 0)
  const save = async ()=>{
    if(items.length===0) return alert('أضف عناصر')
    const { data:order, error } = await supabase.from('orders').insert([{ customer_name: customer, total }]).select().single()
    if(error) return alert(error.message)
    const payload = items.map(x=>({ order_id: order.id, product_id: x.id, qty: x.qty, unit_price: x.price }))
    const { error:err } = await supabase.from('order_items').insert(payload)
    if(err) return alert(err.message)
    alert('تم الحفظ'); setItems([]); setCustomer('')
  }
  return (
    <div className="card">
      <h3>المبيعات</h3>
      <div className="form-row">
        <input className="input" placeholder="اسم الزبون (اختياري)" value={customer} onChange={e=>setCustomer(e.target.value)} />
      </div>
      <div className="form-row" style={{marginTop:8,flexWrap:'wrap'}}>
        {products.map(p=> <button className="btn ghost" key={p.id} onClick={()=>addItem(p)}>{p.name} — {Number(p.price).toFixed(2)}</button>)}
      </div>
      <div style={{marginTop:10}}>
        {items.map(it=>(
          <div key={it.id} className="row" style={{justifyContent:'space-between',marginBottom:6}}>
            <div>{it.name}</div>
            <input className="input" type="number" value={it.qty} onChange={e=>setQty(it.id, e.target.value)} style={{width:90}} />
            <div>{(it.qty*it.price).toFixed(2)}</div>
          </div>
        ))}
      </div>
      <div className="row" style={{justifyContent:'space-between',marginTop:10}}>
        <b>الإجمالي: {total.toFixed(2)}</b>
        <button className="btn primary" onClick={save} disabled={!items.length}>حفظ</button>
      </div>
    </div>
  )
}
