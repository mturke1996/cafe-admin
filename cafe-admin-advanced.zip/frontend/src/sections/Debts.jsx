import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabaseClient'

export default function Debts(){
  const [customer,setCustomer]=useState(''); const [amount,setAmount]=useState(''); const [note,setNote]=useState('')
  const [rows,setRows]=useState([])
  const load = async ()=>{ const { data } = await supabase.from('debts').select('*').order('created_at',{ascending:false}); setRows(data||[]) }
  useEffect(()=>{ load() },[])
  const add = async ()=>{
    if(!customer||!amount) return alert('أدخل الاسم والمبلغ')
    const { error } = await supabase.from('debts').insert([{ customer, amount:Number(amount), note }])
    if(error) return alert(error.message)
    setCustomer(''); setAmount(''); setNote(''); load()
  }
  return (
    <div className="card">
      <h3>ديون الزبائن</h3>
      <div className="form-row">
        <input className="input" placeholder="اسم الزبون" value={customer} onChange={e=>setCustomer(e.target.value)} />
        <input className="input" placeholder="المبلغ" value={amount} onChange={e=>setAmount(e.target.value)} />
        <input className="input" placeholder="ملاحظة" value={note} onChange={e=>setNote(e.target.value)} />
        <button className="btn primary" onClick={add}>إضافة</button>
      </div>
      <table className="table" style={{marginTop:10}}>
        <thead><tr><th>الزبون</th><th>المبلغ</th><th>ملاحظة</th><th>تاريخ</th></tr></thead>
        <tbody>{rows.map(r=>(<tr key={r.id}><td>{r.customer}</td><td>{Number(r.amount).toFixed(2)}</td><td>{r.note}</td><td>{new Date(r.created_at).toLocaleDateString('ar-EG')}</td></tr>))}</tbody>
      </table>
    </div>
  )
}
