# Cafe Admin Advanced (React + Supabase)

- تصميم فاتح متجاوب مع الهاتف
- تسجيل دخول/خروج عبر Supabase Auth
- إدارة الموظفين، الحضور، السحوبات
- منتجات، مبيعات، ديون، مصروفات
- تقارير للطباعة / PDF

## التشغيل
```bash
npm install
npm run dev
```

ضع قيم Supabase في `.env` (انسخ من `.env.example`).

## إنشاء الجداول
نفّذ `../supabase_init.sql` داخل Supabase SQL Editor ثم أنشئ Bucket باسم `employee-photos` في Storage.
