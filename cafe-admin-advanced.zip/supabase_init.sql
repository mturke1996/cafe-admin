-- Extensions
create extension if not exists pgcrypto;

-- Employees
create table if not exists employees(
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  daily_rate numeric(12,2) default 0,
  photo_url text,
  created_at timestamptz default now()
);

-- Attendance
create table if not exists attendance(
  id uuid primary key default gen_random_uuid(),
  employee_id uuid references employees(id) on delete cascade,
  date date not null,
  status text check (status in ('present','absent')),
  created_at timestamptz default now()
);

-- Withdrawals
create table if not exists withdrawals(
  id uuid primary key default gen_random_uuid(),
  employee_id uuid references employees(id) on delete cascade,
  amount numeric(12,2) not null,
  date date not null,
  created_at timestamptz default now()
);

-- Products
create table if not exists products(
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric(12,2) not null,
  created_at timestamptz default now()
);

-- Orders
create table if not exists orders(
  id uuid primary key default gen_random_uuid(),
  customer_name text,
  total numeric(12,2) default 0,
  created_at timestamptz default now()
);

create table if not exists order_items(
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  qty int not null,
  unit_price numeric(12,2) not null
);

-- Debts
create table if not exists debts(
  id uuid primary key default gen_random_uuid(),
  customer text not null,
  amount numeric(12,2) not null,
  note text,
  created_at timestamptz default now()
);

-- Expenses
create table if not exists expenses(
  id uuid primary key default gen_random_uuid(),
  title text not null,
  amount numeric(12,2) not null,
  created_at timestamptz default now()
);
